package com.chainsys.day2;

public class Vehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String no="TN 47 M 2000";
		String name="MT";
		int model=22;
		String wname="Pravin";
		String indate="12-dec-2021 to 11-dec-2022";
		
		System.out.println("Vehicle No.:"+no+"\nVehicle Name:"+name+"\nModel No.:"+model+"\nOwner Name:"+wname+
				"\nInsurance Date:"+indate);
	}

}
