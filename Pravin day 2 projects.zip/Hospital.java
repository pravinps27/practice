package com.chainsys.day2;

public class Hospital {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name="janu";
		int id=13;
		int age=23;
		double weight=56.50d;
		String cause="fever";
		String doj="14 NOV 2022";
		String con="Dr.Ram";
		
		System.out.println("Patient Name:"+ name+"\nPatient Id:"+id +"\nAge:"+age+"\nWeight:"+weight+
				"\nDescription:"+cause+ "\nAppointment Date:"+doj +"\nConsulted Doctor Name:"+con);

	}

}
