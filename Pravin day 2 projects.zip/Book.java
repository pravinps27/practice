package com.chainsys.day2;

public class Book {
	public static void main(String[] args) {
		String name="Wings of Fire";
		int id=321;
		String author="John";
		int yr=2000;
		String rate="Rs. 250.00";
		int vol=1;
		String date="14.nov.2022";
		
		System.out.println("Book Details"+"\n"+"Book name:" +name +"\n" +"Book Id:"+id+"\n"+"Author Name:"+ name+"\n"+"Published year:"+yr+"\n"+"Price:"+rate+"\n"+"Volume:"+vol);
		
	}

}
